import XCTest

import GameTests

var tests = [XCTestCaseEntry]()
tests += GameTests.allTests()
XCTMain(tests)
