struct Game {
    var text = "Hello, World!"
}
