//
//  NotificationView.swift
//  WatchApp Extension
//
//  Created by ZhuXueliang on 2019/11/16.
//  Copyright © 2019 iossocket. All rights reserved.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Hello World")
    }
}

#if DEBUG
struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
#endif
