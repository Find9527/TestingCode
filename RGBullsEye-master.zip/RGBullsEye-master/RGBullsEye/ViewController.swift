//
//  ViewController.swift
//  RGBullsEye
//
//  Created by ZhuXueliang on 2019/11/6.
//  Copyright © 2019 iossocket. All rights reserved.
//

import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.red
    }
}

struct ViewControllerPreviews: PreviewProvider {
    static var previews: some View {
        ViewControllerRepresentation()
    }
}
